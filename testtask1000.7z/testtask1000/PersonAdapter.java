package com.example.testtask1000;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;
import com.example.testtask1000.Model.Person;

import java.util.List;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.ePerson> {

    List<Person> mpersons;
    Fragment fragment;
    Context context;
    OnSendData onSendData;

    public interface OnSendData{

        public void click(Person person);

    }

    public PersonAdapter(Fragment fragment,List<Person> persons) {
        this.mpersons = persons;
        this.fragment = fragment;

        onSendData = (OnSendData)fragment.getActivity();
    }

    @NonNull
    @Override
    public ePerson onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        final int t = i;
        context = viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.person_model,viewGroup,false);



        ePerson task = new ePerson(view, mpersons);



        return task;

    }

    @Override
    public void onBindViewHolder(@NonNull final PersonAdapter.ePerson task, int i) {
        task.bind(i);


        // holder.checkBox.setTag(R.integer.btnplusview, convertView);






    }

    @Override
    public int getItemCount() {
        return mpersons.size();
    }




    public class ePerson extends RecyclerView.ViewHolder implements View.OnClickListener{


        TextView name;
        TextView gender;
        ImageView imageView;

        public ePerson(@NonNull final View itemView, final List<Person> persons) {
            super(itemView);
            itemView.setOnClickListener(this);
            name = itemView.findViewById(R.id.nameTextView);
            gender = itemView.findViewById(R.id.genderTextView);
            imageView = itemView.findViewById(R.id.ImageView);



        }



        public void  bind(int position){



            name.setText(mpersons.get(position).getFirstName());

            gender.setText(mpersons.get(position).getGender());
            String pho = mpersons.get(position).getPhoto();

            Glide.with(context)
                    .load(pho)
                    .into(imageView);

        }





        @Override
        public void onClick(View v) {

            if (onSendData != null){
                Log.i("onSendData", "work in forecast adapter");
                onSendData.click(mpersons.get(getAdapterPosition()));}
            else{
                Log.i("onSendData", " dont work");}



        }


    }
}