package com.example.testtask1000.Fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.testtask1000.Model.Person;
import com.example.testtask1000.R;


public class PersonData extends Fragment {

    TextView name, gender, email, ipaddress, job;
    ImageView  imageView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_person_data, container, false);

        name = rootView.findViewById(R.id.name);
        gender = rootView.findViewById(R.id.gender);
        email = rootView.findViewById(R.id.email);
        ipaddress = rootView.findViewById(R.id.ipaddress);
        job = rootView.findViewById(R.id.job);
        imageView = rootView.findViewById(R.id.image);

        Person person= getArguments().getParcelable("Data");

        name.setText(person.getFirstName() + " " + person.getLastName());
        job.setText(person.getEmployment().getName() + " " + person.getEmployment().getPosition());
        gender.setText(person.getGender());
        email.setText(person.getEmail());
        ipaddress.setText(person.getIpAddress());

        String pho = person.getPhoto();

        Glide.with(this.getContext())
                .load(pho)
                .into(imageView);

        return rootView;
    }

}
