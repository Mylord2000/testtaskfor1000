package com.example.testtask1000.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.util.Log;

import com.example.testtask1000.API;
import com.example.testtask1000.Model.Person;
import com.example.testtask1000.PersonAdapter;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import com.example.testtask1000.R;


public class ListOfPersons extends Fragment {

    ArrayList<Person> persons;

    JsonArray a = new JsonArray();


    RecyclerView rv;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_list_of_persons, container, false);

        rv = rootView.findViewById(R.id.tasksRecycler);

        persons = new ArrayList<Person>();



        getData();


        Log.i("fragment","fragmentfragmentfragmentfragment");
        return rootView;
     }

     public void getData()
     {

         Retrofit retrofit = new Retrofit.Builder()
                 .baseUrl(API.BASE_URL)
                 .addConverterFactory(GsonConverterFactory.create())
                 .build();

         API api = retrofit.create(API.class);

         Call<JsonArray> call = api.getPersons();

         call.enqueue(new Callback<JsonArray>() {
             @Override
             public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {

                 if(response.isSuccessful()){

                     a = response.body();

                     Type listType = new TypeToken<List<Person>>() {}.getType();
                     persons = new Gson().fromJson(a, listType);
                     LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
                     rv.setLayoutManager(layoutManager);
                     rv.addItemDecoration(new DividerItemDecoration(rv.getContext(), DividerItemDecoration.VERTICAL));




                     PersonAdapter ta = new PersonAdapter(ListOfPersons.this, persons);

                     rv.setAdapter(ta);

                 }else {
                     Log.i("result", "ERRORR");
                 }

             }


             @Override
             public void onFailure(Call<JsonArray> call, Throwable t) {
                 Log.d("result","kjhkjhk");
             }
         });

     }

}
