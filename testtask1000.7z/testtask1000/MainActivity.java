package com.example.testtask1000;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.testtask1000.Fragment.ListOfPersons;
import com.example.testtask1000.Fragment.PersonData;
import com.example.testtask1000.Model.Person;


public class MainActivity extends AppCompatActivity  implements PersonAdapter.OnSendData {

    FragmentManager fm;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListOfPersons listOfPersons = new ListOfPersons();

        fm = getSupportFragmentManager();

        fm.beginTransaction().replace(R.id.container, listOfPersons, null).commit();

    }

    @Override
    public void click(Person person) {
        PersonData personData = new PersonData();
        Bundle bundle = new Bundle();
        bundle.putParcelable("Data", person);
        personData.setArguments(bundle);
        fm.beginTransaction().replace(R.id.container, personData,null).addToBackStack(null).commit();

    }
}
