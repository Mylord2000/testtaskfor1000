package com.example.testtask1000;

import com.google.gson.JsonArray;

import retrofit2.Call;
import retrofit2.http.GET;

public interface API {
    public String BASE_URL = "http://www.mocky.io";

    @GET("/v2/5a488f243000004c15c3c57e")
    Call<JsonArray> getPersons();
}
